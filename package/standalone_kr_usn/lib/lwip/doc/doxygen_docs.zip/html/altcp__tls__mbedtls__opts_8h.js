var altcp__tls__mbedtls__opts_8h =
[
    [ "ALTCP_MBEDTLS_DEBUG", "altcp__tls__mbedtls__opts_8h.html#a7727456eeb0b3311213936413d238989", null ],
    [ "ALTCP_MBEDTLS_SESSION_CACHE_TIMEOUT_SECONDS", "altcp__tls__mbedtls__opts_8h.html#a6acb28346f87b2310fc00ec1fccba2b6", null ],
    [ "LWIP_ALTCP_TLS_MBEDTLS", "altcp__tls__mbedtls__opts_8h.html#ac8dbfe10a4a9a64c1e2c62ea97e48639", null ]
];