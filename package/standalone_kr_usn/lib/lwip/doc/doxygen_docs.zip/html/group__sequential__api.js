var group__sequential__api =
[
    [ "Netconn API", "group__netconn.html", "group__netconn" ],
    [ "NETIF API", "group__netifapi.html", "group__netifapi" ]
];