var group__lwip__opts__timers =
[
    [ "LWIP_TIMERS", "group__lwip__opts__timers.html#ga25a41610055f91cbd0960256240b8f2c", null ],
    [ "LWIP_TIMERS_CUSTOM", "group__lwip__opts__timers.html#gaff0ea56f3e3d8e86c49b50557bc13815", null ]
];