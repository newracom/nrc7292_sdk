var group__netifapi =
[
    [ "NETIF related", "group__netifapi__netif.html", "group__netifapi__netif" ],
    [ "DHCPv4", "group__netifapi__dhcp4.html", "group__netifapi__dhcp4" ],
    [ "AUTOIP", "group__netifapi__autoip.html", "group__netifapi__autoip" ]
];